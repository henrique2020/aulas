package view;

import java.util.Scanner;

import model.Aluno;
import model.Turma;

public class InterfaceDeUsuario {

	private Turma[] turmas = new Turma[100];
	private int quantasTurmas = 0;
	private Aluno[] alunos = new Aluno[1000];
	private int quantosAlunos = 0;
	private Scanner entrada = new Scanner(System.in);
		
	public void menuPrincipal() {
		
		//vari�veis tempor�rias
		String nome, cpf, codigo, nomeDisc;
		Aluno tempAluno;
		Turma tempTurma;
		int vagas;
		
		int opcao = this.pegaOpcao();
		while(opcao != 0) {
			switch(opcao) {
			case 1: //Cadastrar um aluno
				System.out.println("Nome: ");
				entrada.nextLine();
				nome = entrada.nextLine();
				System.out.println("Cpf: ");
				cpf = entrada.nextLine();
				tempAluno = new Aluno(nome,cpf);
				alunos[quantosAlunos] = tempAluno;
				quantosAlunos++;
				break;
			case 2://Cadastrar uma turma
				System.out.println("Codigo: ");
				entrada.nextLine();
				codigo = entrada.nextLine();
				System.out.println("Nome da Disciplina: ");
				nomeDisc = entrada.nextLine();
				System.out.println("N�mero de vagas: ");
				vagas = entrada.nextInt();
				tempTurma = new Turma(codigo,nomeDisc,vagas);
				turmas[quantasTurmas] = tempTurma;
				quantasTurmas++;
				
				break;
			case 3://Matricular um aluno em uma turma
				System.out.println("Nome do aluno para matricular: ");
				entrada.nextLine();
				nome = entrada.nextLine();
				System.out.println("Codigo da turma: ");
				codigo = entrada.nextLine();
				tempAluno = null;
				for(int i=0 ; i<quantosAlunos ; i++) {
					if(nome.equals(alunos[i].getNome())) {
						tempAluno = alunos[i];
						break;
					}
				}
				if(tempAluno == null) {
					System.out.println("Aluno n�o cadastrado!");
				}
				else {
					tempTurma = null;
					for(int i=0 ; i<quantasTurmas ; i++) {
						if(codigo.equals(turmas[i].getCodigo())) {
							tempTurma = turmas[i];
							break;
						}
					}
					if(tempTurma == null) {
						System.out.println("Turma n�o cadastrada!");
					}
					else {
						tempTurma.matricular(tempAluno);
					}
				}
				break;
				
			case 4: //Mostrar os alunos matriculados em uma turma
				System.out.println("Codigo da turma: ");
				entrada.nextLine();
				codigo = entrada.nextLine();
				tempTurma = null;
				for(int i=0 ; i<quantasTurmas ; i++) {
					if(codigo.equals(turmas[i].getCodigo())) {
						tempTurma = turmas[i];
						break;
					}
				}
				if(tempTurma == null) {
					System.out.println("Turma n�o cadastrada!");
				}
				else {
	
					for(int i=0 ; i<tempTurma.getQuantosAlunos() ; i++) {
						tempAluno = tempTurma.getALuno(i);
						System.out.println("Nome: "+tempAluno.getNome());
					}
					
					
//					String[] aux = tempTurma.nomes();
//					for(String nomeTemp : aux) {
//						System.out.println( nomeTemp );
//					}
//					
//					for(int i=0 ; i< aux.length ; i++) {
//						System.out.println(aux[i]);
//					}
				}
				
			}
			opcao = this.pegaOpcao();
		}
				
		
		
	}
	
	private int pegaOpcao() {
		int opcao;	
		System.out.println("0.Sair");
		System.out.println("1.Cadastrar um aluno");
		System.out.println("2.Cadastrar uma turma");
		System.out.println("3.Matricular um aluno em uma turma");
		System.out.println("4.Mostrar os alunos matriculados em uma turma");
		opcao = entrada.nextInt();
		return opcao;
	}
	
	
}
