package model;

public class Professor {

}
