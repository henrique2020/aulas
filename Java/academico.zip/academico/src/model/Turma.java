package model;

public class Turma {

	private String codigo;
	private String nomeDaDisciplina;
	private Professor prof;
	
	private Aluno[] matriculados ;
	private int quantosAlunos = 0;
	
	public Turma(String codigo, String nomeDaDisciplina, int numeroDeVagas) {
		this.matriculados = new Aluno[numeroDeVagas];
		this.codigo = codigo;
		this.nomeDaDisciplina = nomeDaDisciplina;
	}
	
	public void matricular(Aluno alunoParaMatricular) {
		matriculados[quantosAlunos]  = alunoParaMatricular;
		quantosAlunos++;	
	}
	
	public String[] nomes() {
		String[] tempNomes = new String[this.quantosAlunos];
		for(int i=0 ; i<this.quantosAlunos;i++) {
			tempNomes[i] = matriculados[i].getNome();
		}
		return tempNomes;
	}
	
	public Aluno getALuno(int indice) {
		if(indice>=0 && indice<quantosAlunos) {
			return matriculados[indice];
		}
		return null;
	}
	
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getNomeDaDisciplina() {
		return nomeDaDisciplina;
	}
	public void setNomeDaDisciplina(String nomeDaDisciplina) {
		this.nomeDaDisciplina = nomeDaDisciplina;
	}
	public Professor getProf() {
		return prof;
	}
	public void setProf(Professor prof) {
		this.prof = prof;
	}
	public int getQuantosAlunos() {
		return quantosAlunos;
	}
	public void setQuantosAlunos(int quantosAlunos) {
		this.quantosAlunos = quantosAlunos;
	}
	

	
}
