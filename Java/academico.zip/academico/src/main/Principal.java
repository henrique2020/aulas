package main;

import view.InterfaceDeUsuario;

public class Principal {

	public static void main(String[] args) {
		InterfaceDeUsuario inter = new InterfaceDeUsuario();
		inter.menuPrincipal();
	}

}
