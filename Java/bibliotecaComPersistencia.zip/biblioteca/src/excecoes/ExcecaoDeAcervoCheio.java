package excecoes;

public class ExcecaoDeAcervoCheio extends Exception{

	@Override
	public String getMessage() {
		return "A inclus�o n�o aconteceu porque o acervo estava cheio!";
	}
	
}
