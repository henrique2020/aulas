package excecoes;

public class ExcecaoDeLivroComMesmoTitulo extends Exception {

}
