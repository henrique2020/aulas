package persistencia;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import entidades.Acervo;

public class PersistenciaComSerializacao implements Persistidor{

	@Override
	public void salvarAcervo(Acervo acervo) {

		try {
			FileOutputStream fs = new FileOutputStream("livros.obj");
			ObjectOutputStream escreve = new ObjectOutputStream(fs);
			escreve.writeObject(acervo);
			escreve.flush();
			escreve.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Erro de IO");
		}
	
	}

	@Override
	public Acervo recuperarAcervo() {
		Acervo tempAcervo = new Acervo(100);
		try {
			FileInputStream fs = new FileInputStream("livros.obj");
			ObjectInputStream leitor = new ObjectInputStream(fs);
			tempAcervo = (Acervo) leitor.readObject();

			leitor.close();
			
			
		} catch (IOException  e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Erro de IO");
		}catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Erro de Classe");
		}
		return tempAcervo;
	}

}








