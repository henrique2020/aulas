package persistencia;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import entidades.Acervo;
import entidades.Livro;
import excecoes.ExcecaoDeAcervoCheio;
import excecoes.ExcecaoDeLivroComMesmoTitulo;

public class PersistenciaComArquivoTexto implements Persistidor {

	@Override
	public void salvarAcervo(Acervo acervo) {

		try {
			FileWriter fw = new FileWriter("livros.txt");
			BufferedWriter escrevedor = new BufferedWriter(fw);
			Livro tempLivro;
			for(int i=0 ; i< acervo.getTamanho()    ; i++) {
				tempLivro = acervo.getLivro(i);
				escrevedor.write(tempLivro.getTitulo());
				escrevedor.newLine();
				escrevedor.write(String.valueOf(tempLivro.getAnoDePublicacao()));
				escrevedor.newLine();
				escrevedor.write(tempLivro.getAutor());
				escrevedor.newLine();
			}
			escrevedor.flush();
			escrevedor.close();
		} catch (IOException e) {
			System.out.println("Erro de IO!");
			//e.printStackTrace();
		}
	}

	@Override
	public Acervo recuperarAcervo() {
		Acervo tempAcervo = new Acervo(100);
		
		try {
			FileReader fr = new FileReader("livros.txt");
			BufferedReader leitor = new BufferedReader(fr);
			String titulo, autor;
			int ano ;
			titulo = leitor.readLine();
			while(titulo != null) {
				ano = Integer.parseInt(leitor.readLine());
				autor = leitor.readLine(); 
				tempAcervo.incluirLivro(new Livro(titulo,ano,autor));
				titulo = leitor.readLine();
			}
			leitor.close();
		}catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (IOException e) {
			System.out.println("Erro de IO!");
			//e.printStackTrace();
		} catch (ExcecaoDeAcervoCheio e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExcecaoDeLivroComMesmoTitulo e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		return tempAcervo;
	}

}
