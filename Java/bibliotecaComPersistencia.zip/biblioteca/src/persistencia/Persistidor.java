package persistencia;

import entidades.Acervo;

public interface Persistidor {

	public void salvarAcervo(Acervo acervo);
	public Acervo recuperarAcervo();
	
}
