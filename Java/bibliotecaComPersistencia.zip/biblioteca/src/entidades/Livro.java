package entidades;

import java.io.Serializable;

public class Livro implements Serializable {

	private String titulo;
	private int anoDePublicacao;
	private String autor;
	
	public Livro(String titulo, int anoDePublicacao) {
		this.titulo = titulo;
		this.anoDePublicacao = anoDePublicacao;
	}

	public Livro(String titulo, int anoDePublicacao, String autor) {
		this.titulo = titulo;
		this.anoDePublicacao = anoDePublicacao;
		this.autor = autor;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public int getAnoDePublicacao() {
		return anoDePublicacao;
	}

	public void setAnoDePublicacao(int anoDePublicacao) {
		this.anoDePublicacao = anoDePublicacao;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}
	
	
	
	
}
