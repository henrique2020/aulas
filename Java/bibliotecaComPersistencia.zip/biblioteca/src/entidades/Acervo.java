package entidades;

import java.io.Serializable;

import excecoes.ExcecaoDeAcervoCheio;
import excecoes.ExcecaoDeLivroComMesmoTitulo;

public class Acervo implements Serializable {

	private int capacidade;
	private Livro[] livros;
	private int tamanho = 0;

	public Acervo(int capacidade) {
		this.capacidade = capacidade;
		livros = new Livro[capacidade];
	}

	public  void  incluirLivro(Livro livroAIncluir) 
			throws ExcecaoDeAcervoCheio, ExcecaoDeLivroComMesmoTitulo
	{
		if(tamanho == capacidade) {
			throw new ExcecaoDeAcervoCheio();
		}
		for(int i=0 ; i<tamanho ; i++) {
			if(livroAIncluir.getTitulo().equals(livros[i].getTitulo())){
				throw new ExcecaoDeLivroComMesmoTitulo();
			}
		}
		livros[tamanho] = livroAIncluir;
		tamanho++;
	}

	public Livro[]  pesquisa(int ano) {
		int quantos = 0;
		for(int i=0 ; i<tamanho ; i++) {
			if(livros[i].getAnoDePublicacao()>ano){
				quantos++;
			}
		}
		Livro[] temp = new Livro[quantos];
		int j=0;
		for(int i=0 ; i<tamanho ; i++) {
			if(livros[i].getAnoDePublicacao()>ano){
				temp[j] = livros[i];
				j++;
			}
		}
		return temp;
	}
	
	public Livro getLivro(int indice) {
		if(indice>=0 && indice<this.tamanho) {
			return livros[indice];
		}
		return null;
	}
	
	public int getTamanho() {
		return tamanho;
	}

	public int getCapacidade() {
		return capacidade;
	}
	
	
	
	
}
