package view;

import persistencia.PersistenciaComArquivoTexto;
import persistencia.PersistenciaComSerializacao;

public class Principal {

	public static void main(String[] args) {
		new InterfaceDeUsuario(new PersistenciaComSerializacao()).menu();
	}

}
