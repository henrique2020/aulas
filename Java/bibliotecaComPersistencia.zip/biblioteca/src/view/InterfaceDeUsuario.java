package view;

import java.util.Scanner;

import entidades.Acervo;
import entidades.Livro;
import excecoes.ExcecaoDeAcervoCheio;
import excecoes.ExcecaoDeLivroComMesmoTitulo;
import persistencia.Persistidor;

public class InterfaceDeUsuario {

	private Acervo acervoDaBiblioteca ;
	private Scanner entrada = new Scanner(System.in);
	private Persistidor persiste;
	
	public InterfaceDeUsuario(Persistidor persiste) {
		this.persiste = persiste;
	}
	
	public void menu() {
		// vari�veis locais
		String titulo,autor;
		int ano,resultado;
		
		acervoDaBiblioteca = persiste.recuperarAcervo();
		
		System.out.println("0.Sair");
		System.out.println("1.Incluir livros no acervo");
		System.out.println("2.Pesquisar livros por ano");
		System.out.println("3.Listar livros");
		int opcao = entrada.nextInt();
		while(opcao!=0) {
			switch(opcao) {
			case 1: //Incluir livros no acervo
				try {
					System.out.println("T�tulo do Livro : ");
					entrada.nextLine();
					titulo = entrada.nextLine();
					System.out.println("Ano de publica��o : ");
					ano = entrada.nextInt();
					System.out.println("Autor : ");
					entrada.nextLine();
					autor = entrada.nextLine();
					acervoDaBiblioteca.incluirLivro(new Livro(titulo,ano,autor));
				}
				catch(ExcecaoDeAcervoCheio e) {
					System.out.println(e.getMessage());
				}
				catch(ExcecaoDeLivroComMesmoTitulo e) {
					System.out.println("j� h� livro com o mesmo t�tulo");
				}
				break;
			case 2: //Pesquisar livros por ano
				System.out.println("Ano para pesquisa : ");
				ano = entrada.nextInt();
				Livro[] temp = acervoDaBiblioteca.pesquisa(ano);
				if(temp.length == 0) {
					System.out.println("nenhum livro encontrado!");
				}
				else {
					for(Livro livro : temp) {
						System.out.println(livro.getTitulo());
					}
				}
				break;
			case 3:
				for(int i=0 ; i< acervoDaBiblioteca.getTamanho() ; i++) {
					System.out.println(acervoDaBiblioteca.getLivro(i).getTitulo());
				}
			}
			
			
			System.out.println("0.Sair");
			System.out.println("1.Incluir livros no acervo");
			System.out.println("2.Pesquisar livros por ano");
			System.out.println("3.Listar livros");

			opcao = entrada.nextInt();
			
		}
		
		persiste.salvarAcervo(acervoDaBiblioteca);
		
		
	}
	
	
}
