package view;

import entidades.Livro;

public class Teste {

	public static void main(String[] args) {

		try {
			Livro l= null; // new Livro("este",2022);
			System.out.println(l.getTitulo());
			System.out.println("depois da exce��o");
		}
		catch(NullPointerException e) {
			e.printStackTrace();
			System.out.println("aconteceu erro de null pointer");
		}
		System.out.println("depois do catch");
	}
}
