package principal;

import visualizacao.InterfaceDeUsuario;

public class Inicial {

	public static void main(String[] args) {
		
		InterfaceDeUsuario interUsuario;
		interUsuario = new InterfaceDeUsuario();
		
		interUsuario.menuPrincipal();
		

	}

}
