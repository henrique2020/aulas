package entidades;

public interface Autenticavel {

	public boolean autentica(int senha);
	
}
