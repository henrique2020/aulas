package entidades;

public class Diretor extends Funcionario {

	public Diretor(String nome, String cpf)
    {
    	super(nome,cpf);
    }
	
}
