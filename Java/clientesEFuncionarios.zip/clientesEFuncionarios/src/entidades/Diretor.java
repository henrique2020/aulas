package entidades;

public class Diretor extends Funcionario implements Autenticavel {

	public Diretor(String nome, String cpf)
    {
    	super(nome,cpf);
    }

	@Override
	public double getBonificacao() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean autentica(int senha) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
