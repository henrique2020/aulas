package entidades;

public class SistemaInterno {
	
	public void login(Autenticavel objeto) {
		
		int senha = 0;
		
		if(objeto.autentica(senha)) {
			
		}
        // Invocar o m�todo autentica?
        // N�o d�! Nem todo Funcionario o tem.
			
    } 
}
