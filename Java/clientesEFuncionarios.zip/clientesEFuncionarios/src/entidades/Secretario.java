package entidades;

public class Secretario extends Funcionario {

	public Secretario(String nome, String cpf)
    {
    	super(nome,cpf);
    }
}
