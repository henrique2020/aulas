package entidades;

public abstract class Funcionario extends Pessoa{
 
	protected double salario;
    
    public Funcionario(String nome, String cpf)
    {
    	super(nome,cpf);
    }
    
    @Override
	public String comoString() {
		return "Nome: "+nome+" Cpf: "+cpf+" Salario: "+salario;
	}
    
    public abstract double getBonificacao();
    
    
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	
}
