package entidades;

public class Gerente extends Funcionario implements Autenticavel {

	private int senha;
	private int numeroDeFuncionariosGerenciados;

	public Gerente(String nome, String cpf)
    {
    	super(nome,cpf);
    }
	
	@Override
	public double getBonificacao() {
		return 1000;
	}
	
	public boolean autentica(int senha) {
		
		String temp = this.cpf;
		
		if (this.senha == senha) {
			System.out.println("Acesso Permitido!");
			return true;
		} else {
			System.out.println("Acesso Negado!");
			return false;
		}
	}
}
