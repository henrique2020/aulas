package entidades;

public class Cliente extends Pessoa implements Autenticavel {

	protected String situacaoDeCredito;
	
	public Cliente(String nome,String cpf,String situacao)
	{
		super(nome,cpf);
		situacaoDeCredito = situacao;
	}

    @Override
	public String comoString() {
		return "Nome: "+nome+" Cpf: "+cpf+" Situa��o de Cr�dito: "+situacaoDeCredito;
	}
	
	public String getSituacaoDeCredito() {
		return situacaoDeCredito;
	}

	public void setSituacaoDeCredito(String situacaoDeCredito) {
		this.situacaoDeCredito = situacaoDeCredito;
	}

	@Override
	public boolean autentica(int senha) {
		// TODO Auto-generated method stub
		return false;
	}
	

	
	
}
