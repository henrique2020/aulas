package entidades;

public class Terceirizado extends Pessoa {
	
	public Terceirizado() {
		super("slkdf","slkdf");
	}

	@Override
	public String comoString() {
		// TODO Auto-generated method stub
		return null;
	}

}
