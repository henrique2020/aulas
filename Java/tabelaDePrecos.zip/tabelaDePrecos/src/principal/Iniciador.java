package principal;

import view.InterfaceDeUsuario;

public class Iniciador {

	public static void main(String[] args) {
		InterfaceDeUsuario inicia = new InterfaceDeUsuario();
		inicia.menu();
	}

}
