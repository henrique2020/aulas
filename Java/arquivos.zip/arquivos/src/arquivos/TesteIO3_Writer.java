package arquivos;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class TesteIO3_Writer {

	public static void main(String[] args) {
		
		try {
			Writer fw = new FileWriter("teste2.txt");
			fw.write("Uma sequência de caracteres qualquer");
			fw.close();
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
}