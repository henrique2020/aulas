package arquivos;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class TesteIO5_BufferedWriter {

	public static void main(String[] args) {
		
		try {
			
			BufferedWriter escreve = new BufferedWriter(new FileWriter("teste2.txt"));
			
			//  Decorator Pattern
			
			escreve.write("Uma sequência de caracteres qualquer");
			escreve.newLine();
			escreve.write("Mais uma frase qualquer e sem sentido!");
			escreve.newLine();
			escreve.write("Mais uma frase qualquer e sem sentido!");
			escreve.newLine();
			escreve.write("Mais uma frase qualquer e sem sentido!");
			escreve.flush();
			escreve.close();
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
}
