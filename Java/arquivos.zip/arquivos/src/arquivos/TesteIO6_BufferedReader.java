package arquivos;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

public class TesteIO6_BufferedReader {

	public static void main(String[] args) {

		try {
			FileReader fr = new FileReader("teste2.txt");
			BufferedReader leitor = new BufferedReader(fr);
					
			String linha = leitor.readLine();
			while(linha!=null)
			{
				System.out.println(linha);
				linha = leitor.readLine();
			}
			fr.close();
		}
		catch(FileNotFoundException e)
		{
			System.out.println("arquivo n�o encontrado!");
		}
		catch(IOException e)
		{
			
		}
		
		
	}

}