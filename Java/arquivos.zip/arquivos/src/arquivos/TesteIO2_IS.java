package arquivos;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class TesteIO2_IS {

	public static void main(String[] args) {

		InputStream is;
		try {
			is = new FileInputStream("teste.txt");
			int result = is.read();
			System.out.println(result);
			is.close();
		} 
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("erro de arquivo n�o encontrado!");
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("FINAL!");
		
	}
}