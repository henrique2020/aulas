
public class Principal {

    public static void main(String[] args) {

        //Define a solu��o
        Algoritmo.setSolucao("A d�vida � o princ�pio da sabedoria");
        //Define os caracteres existentes
        Algoritmo.setCaracteres("!,.:;�����������QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890 ");
        //taxa de crossover de 60%
        Algoritmo.setTaxaDeCrossover(0.6);
        //taxa de muta��o de 3%
        Algoritmo.setTaxaDeMutacao(0.3);
        //elitismo
        boolean eltismo = true;
        //tamanho da popula��o
        int tamPop = 100;
        //numero máximo de gera��es
        int numMaxGeracoes = 10000;

        //define o número de genes do indivíduo baseado na solu��o
        int numGenes = Algoritmo.getSolucao().length();

        //cria a primeira popula��o aleatérioa
        Populacao populacao = new Populacao(numGenes, tamPop);

        boolean temSolucao = false;
        int geracao = 0;

        System.out.println("Iniciando... Aptid�o da solu��o: "+Algoritmo.getSolucao().length());
        
        //loop até o critério de parada
        while (!temSolucao && geracao < numMaxGeracoes) {
            geracao++;

            //cria nova populacao
            populacao = Algoritmo.novaGeracao(populacao, eltismo);

            System.out.println("Gera��o " + geracao + " | Aptid�o: " + populacao.getIndividuo(0).getAptidao() + " | Melhor: " + populacao.getIndividuo(0).getGenes());
            
            //verifica se tem a solucao
            temSolucao = populacao.temSolucao(Algoritmo.getSolucao());
        }

        if (geracao == numMaxGeracoes) {
            System.out.println("Número Maximo de Gera��es | " + populacao.getIndividuo(0).getGenes() + " " + populacao.getIndividuo(0).getAptidao());
        }

        if (temSolucao) {
            System.out.println("Encontrado resultado na gera��o " + geracao + " | " + populacao.getIndividuo(0).getGenes() + " (Aptidão: " + populacao.getIndividuo(0).getAptidao() + ")");
        }
}
}
