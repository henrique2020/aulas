/*

As tarifas de um estacionamento são definidas assim:
● A primeira e a segunda hora custam 5 reais cada.
● A terceira e a quarta hora custam 2 reais cada.
● A partir da quinta hora, cada hora custa 1 real cada.
Assim, se um carro ficar 5 horas no estacionamento, o motorista pagará 15 reais (5+5+2+2+1).
Escreva um programa para ler dois valores, respectivamente a hora de entrada e saída no
estacionamento de um cliente (horas inteiras, sem minutos), e informe o valor a ser pago.
Considere que o usuário deve retirar seu carro antes da meia-noite, ou seja, ele não pode entrar em um dia e sair no dia seguinte.

*/

#include <stdio.h>

int main(void) {
  int entrada, saida, horas, valor;
  printf("Digite a hora de entrada: ");
  scanf("%d", &entrada);
  printf("Digite a hora de saida: ");
  scanf("%d", &saida);

  horas = saida - entrada;
  int h = horas;
  valor = 0;
  if(horas > 4){
    valor += 2*5; //As duas priemiras horas custam R$5,00
    valor += 2*2; //A 3ª e 4ª hora custa R$2,00 cada
    h -= 4;  // Remove as primeiras 4 horas
    valor += h; //A partir da 5ª o valor do estacionamento se torna R$1,00, sendo necessário apenas somar o número de horas então
  }
  else if(horas > 2 && horas < 5){
    valor += 2*5;
    h -= 2;
    valor += h*2; //A partir da 3ª hora custa R$2,00 cada, sendo multiplicado pelo nº de horas
  }
  else{
    valor += h*5;
  }
  printf("O motorista ficou %d horas e terá de pagar R$%d,00\n", horas, valor);

}
