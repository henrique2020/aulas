/*

Escreva um programa para ler 5 valores, cada um deles é um número entre 1 e 6.
Os números correspondem ao resultado de um arremesso de 5 dados no jogo General.
Considere que os valores são informados em ordem crescente
O programa deve escrever o número de pontos que o jogador fez
● 50 - Se os 5 valores são iguais
● 30 - Se há 4 valores iguais e um diferente
● 20 - Se os 5 valores formam uma sequência (1,2,3,4,5 ou 2,3,4,5,6)
● 10 - Se os valores formam um full-hand (3 valores iguais entre si, e os outros dois valores também iguais entre si)
● 0 pontos - Nenhuma das combinações acima

*/

#include <stdio.h>

int main(void) {
  int d1, d2, d3, d4, d5, pontos;

  int dados[5];
  for(int i = 0; i < 5; i++){
    printf("Digite o valor do %dº dado: ", i+1);
    scanf("%d", &dados[i]);
  }

  int um = 0;
  int dois = 0;
  int tres = 0;
  int quatro = 0;
  int cinco = 0;
  int seis = 0;

  for(int i = 0; i < 5; i++){
    if(dados[i] == 1){
      um++;
    }
    if(dados[i] == 2){
      dois++;
    }
    if(dados[i] == 3){
      tres++;
    }
    if(dados[i] == 4){
      quatro++;
    }
    if(dados[i] == 5){
      cinco++;
    }
    if(dados[i] == 6){
      seis++;
    }
  }

  //printf("%d - %d - %d - %d - %d - %d\n",um, dois, tres, quatro, cinco, seis);

  if(um == 5 || dois == 5 || tres == 5 ||  quatro == 5 || cinco == 5 || seis == 5){
    pontos = 50;
  }
  else if(um == 4 || dois == 4 || tres == 4 ||  quatro == 4 || cinco == 4 || seis == 4){
    pontos = 40;
  }
  else if ((um == 3 || dois == 3 || tres == 3 ||  quatro == 3 || cinco == 3 || seis == 3) && (um == 2 || dois == 2 || tres == 2 ||  quatro == 2 || cinco == 2 || seis == 2)){
    pontos = 10;
  }
  else if ((dois == 0 || cinco == 0) && um != 0 && tres != 0 && quatro != 0 && seis != 0){
    pontos = 0;
  }
  else{
    pontos = 20;
  }
  printf("O jogador fez %d pontos\n", pontos);
}
