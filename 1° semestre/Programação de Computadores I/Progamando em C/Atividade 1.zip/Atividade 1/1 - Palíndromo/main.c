/*

Podemos dizer que um número é “palíndromo” se representa o mesmo valor quando lido da esquerda para a direita ou da direita para a esquerda.
Por exemplo: O número 45654 é palíndromo.
Escreva um programa para determinar se um número inteiro com exatamente 5 dígitos é ou não palíndromo. Use os operadores de divisão e resto da divisão inteira (%) para separar os dígitos e compará-los!
O programa deve ler o número (número único em uma única variável).
O programa deve escrever uma das frases abaixo (substituindo as reticências pelo número!)
“O número ... é palíndromo” ou
“O número ... não é palíndromo”
Exemplos:
O número 12345 não é palíndromo
O número 34543 é palíndromo

*/

#include <stdio.h>

int main() {
    int valor, r_valor, div, resto;
    int rv1, rv2, rv3, rv4, rv5;
    printf("Digite um número (5 algorismos): ");
    scanf("%d", &valor);
    r_valor = 0;
    div = valor;

    rv1 = div/10000; //Pega o número mais a esquerda do valor
    div = div - rv1*10000;

    rv2 = div/1000; //Pega o 2º número mais a esquerda do valor
    div = div - rv2*1000;

    rv3 = div/100; //Pega o 3º número mais a esquerda do valor
    div = div - rv3*100;

    rv4 = div/10; //Pega o 4º número mais a esquerda do valor
    resto = div - rv4*10;

    rv5 = resto; //Pega o número mais a direita do valor

    r_valor = (rv5*10000) + (rv4*1000) + (rv3*100) + (rv2*10) + rv1; //Inverte a ordem dos valores

    if (valor == r_valor) {
        printf("O número %d é palíndromo\n", valor);
    }
    else{
        printf("O número %d não é palíndromo\n", valor);
    }
    return 0;
}
