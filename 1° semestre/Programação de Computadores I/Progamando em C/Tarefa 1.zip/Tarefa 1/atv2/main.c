//Faça um algoritmo que leia dois valores inteiros e escreva a sua soma
#include <stdio.h>

int main() {
  int n1, n2, soma;
  scanf("%d %d", &n1, &n2);

  soma = n1+n2;
  printf("%d\n", soma);
  return 0;
}
