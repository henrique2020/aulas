//Fa�a um algoritmo que leia 3 valores reais, notas de um aluno, e escreva sua m�dia aritm�tica. Dica:A m�dia aritm�tica de um conjunto de valores � dada pela soma dos valores dividido pela quantidade de valores considerados. m=(v1+v2+v3)/3
#include <stdio.h>

int main() {
  float n1, n2, n3, media;
  scanf("%f %f %f", &n1, &n2, &n3);

  media = (n1+n2+n3)/3;
  printf("%.1f", media);
  puts("");

  return 0;
}
