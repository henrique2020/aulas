//Fa�a um algoritmo que leia 3 valores a, b e c, coeficientes de uma equa��o de segundo grau, e calcule e escreva a soma das ra�zes da equa��o. Dica:As ra�zes de uma equa��o podem ser calculadas pela f�rmula de Baskhara.
//F�rmula de Bhaskara -> -b +- raiz de b�-4*a*c, tudo dividio por 2*a

#include <stdio.h>
#include<math.h>

int main() {
  float a, b, c, n1, n2, delta, soma;
  scanf("%f %f %f", &a, &b, &c);
  delta = sqrt((b*b)+(-4*a*c));
  n1 = (-b+delta)/(2*a);
  n2 = (-b-delta)/(2*a);

  soma = n1+n2;
  printf("%.2f\n", soma);

  return 0;
}
