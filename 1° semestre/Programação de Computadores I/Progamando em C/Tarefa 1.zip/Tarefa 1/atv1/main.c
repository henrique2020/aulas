//Faça um algoritmo que leia um valor N, representando o lado de um quadrado, e calcule e escreva a área do quadrado. Dica:A área de um quadrado de lado N é dada por N x N.
#include <stdio.h>

int main() {
  float lado;
  scanf("%f", &lado);

  float area = lado*lado;
  printf("%.2f", area);

  return 0;
}
