//Fa�a um algoritmo que leia 2 valores reais v1 e v2 e calcule e escreva a �rea do tri�ngulo que tem base igual a v1 e altura igual a v2. Dica:A �rea de um tri�ngulo � dada pela express�o: (base x altura)/2
#include <stdio.h>

int main() {
  float v1, v2, area;
  scanf("%f %f", &v1, &v2);

  area = (v1*v2)/2;
  printf("%.2f"\n, area);
  return 0;
}
