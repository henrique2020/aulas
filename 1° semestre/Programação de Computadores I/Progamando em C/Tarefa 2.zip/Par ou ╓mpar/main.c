// C-40
// Autor : rique_hahn
// Data : 19/08/2021
#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);
    if(n%2 == 0){
        printf("O n�mero � par\n"); //No meu console, os caracteres com acento ficam estranhos...
    }
    else{
        printf("O n�mero � �mpar\n");
    }
    return 0;
}
