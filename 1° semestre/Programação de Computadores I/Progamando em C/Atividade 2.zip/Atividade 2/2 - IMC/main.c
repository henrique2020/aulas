/*
O índice de massa corporal (IMC) de uma pessoa é dada pela relação

 imc = peso / (altura*altura)

Escreva um algoritmo para ler o peso e altura de um grupo de pessoas e fornecer (escrever) as seguintes informações:

O peso e a altura da pessoa de maior IMC
A altura da pessoa mais alta
O peso da pessoa mais leve
Considere que:

A quantidade de pessoas no grupo será lida no início do algoritmo
Serão fornecidos o peso e a altura da primeira pessoa, depois o peso e a altura da segunda pessoa, e assim sucessivamente até que o peso e a altura da última pessoa tenham sido lidos.
*/

/*
O índice de massa corporal (IMC) de uma pessoa é dada pela relação

 imc = peso / (altura*altura)

Escreva um algoritmo para ler o peso e altura de um grupo de pessoas e fornecer (escrever) as seguintes informações:

O peso e a altura da pessoa de maior IMC
A altura da pessoa mais alta
O peso da pessoa mais leve
Considere que:

A quantidade de pessoas no grupo será lida no início do algoritmo
Serão fornecidos o peso e a altura da primeira pessoa, depois o peso e a altura da segunda pessoa, e assim sucessivamente até que o peso e a altura da última pessoa tenham sido lidos.
*/

#include <stdio.h>

int main(void) {
  int rep;
  printf("Digite o número de pessoas: ");
  scanf("%d", &rep);

  float imc, imcA, imcP, altura, peso; //Maior IMC, maior altura, menor peso
  float tempImc, tempAltura, tempPeso;
  printf("Utilize '.' ao invés de ',' para valores quebrados!\n\n");

  printf("Digite o peso (em Kg): ");
  scanf("%f", &tempPeso);
  printf("Digite a altura (em m): ");
  scanf("%f", &tempAltura);
  printf("\n");
  tempImc = tempPeso / (tempAltura * tempAltura);

  imc = tempImc;
  imcA = tempAltura;
  imcP = tempPeso;
  altura = tempAltura;
  peso = tempPeso;

  for(int i = 1; i < rep; i++){ //i = 1, pois já foi feita a uma verificação
    printf("Digite o peso (em Kg): ");
    scanf("%f", &tempPeso);
    printf("Digite a altura (em m): ");
    scanf("%f", &tempAltura);
    printf("\n");
    tempImc = tempPeso / (tempAltura * tempAltura);

    if(tempImc > imc){
      imc = tempImc;
      imcA = tempAltura;
      imcP = tempPeso;
    }
    if(tempAltura > altura){
      altura = tempAltura;
    }
    if(tempPeso < peso){
      peso = tempPeso;
    }

  }
  printf("A pessoa com maior IMC pesa %.2f Kg e mede %.2f m\n", imcP, imcA);
  printf("O menor peso foi %.2f Kg\n", peso);
  printf("A maior altura foi %.2f m\n", altura);
  return 0;
}
