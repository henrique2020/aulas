//Escreve um programa em C para ler 20 números. O programa deve apresentar, ao final, a média dos números pares digitados (soma dos pares dividido pela quantidade de pares).

#include <stdio.h>
int main(void) {
  float media, soma = 0.00;
  int tempValor, count = 0; //Armazena o valor digitado temporáriamente

  for(int i = 0; i < 20; i++){
    printf("Digite um número: ");
    scanf("%d", &tempValor);
    if(tempValor % 2 == 0){
      soma += tempValor;
      count++;
    }
  }

  media = soma / count * 1.00;
  printf("A média dos números pares é: %.2f\n", media);
}
