//Dois números n1 e n2 são ditos amigos entre si se a soma dos divisores de n1 (excluindo o próprio n1) é igual a n2, e a soma dos divisores de n2 (excluindo o próprio n2) é igual a n1. Ex: 220 e 284. Faça um algoritmo que leia 2 valores e verifique se são amigos entre si escrevendo: 1 - se são amigos; 0 - se não são amigos.

//rique_hahn
//13/10/2021
#include <stdio.h>

int main() {
    int n1, n2, s1, s2;
    printf("Digite o valor 1: ");
    scanf("%d", &n1);

    printf("Digite o valor 2: ");
    scanf("%d", &n2);

    s1 = 0;
    s2 = 0;
    for(int rep = 1; rep < n1; rep++){
        if(n1%rep == 0){
            s1+=rep;
        }
    }
    for(int rep = 1; rep < n2; rep++){
        if(n2%rep == 0){
            s2+=rep;
        }
    }
    if(s1 == n2 && s2 == n1){
        printf("Os valores %d e %d são amigos\n", n1, n2);
    }
    else{
        printf("Os valores %d e %d NÃO são amigos\n", n1, n2);
    }
    return 0;
}
