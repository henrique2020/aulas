//Um número inteiro maior do que 1 é primo se ele possui como divisores somente o 1 e ele mesmo. Faça um algoritmo que leia um número e verifique se é primo escrevendo: 1 - se o número é primo; 0 - se o número não é primo. Dica:Pode-se também verificar se um número é primo encontrando seu primeiro divisor maior que 1. Se o primeiro divisor for o próprio número, ele é primo.

//rique_hahn
//13/10/2021
#include <stdio.h>

int main() {
    int n;
    printf("Digite um valor: ");
    scanf("%d", &n);

    for(int rep = 2; rep <= n; rep++){
        if(rep == n){
            printf("O número %d é primo!\n", n);
        }
        else if(n%rep == 0){
            printf("O número %d não é primo, pois é divisível por %d\n", n, rep);
            break;
        }
    }
    return 0;
}
