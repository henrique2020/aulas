//Faça um algoritmo que leia um valor N inteiro e maior do que 1, e calcule e escreva o seu menor divisor maior do que 1.

//rique_hahn
//13/10/2021
#include <stdio.h>

int main() {
    int n;
    printf("Digite um valor: ");
    scanf("%d", &n);

    for(int rep = 2; rep < n; rep++){
        if(n%rep == 0){
            printf("O número %d é o menor divisor de %d\n", rep, n);
            break;
        }
    }
    return 0;
}
