//Faça um algoritmo que leia um valor N inteiro e maior do que 1, e calcule e escreva o seu maior divisor (excetuando N)

//rique_hahn
//13/10/2021
#include <stdio.h>

int main() {
    int n;
    printf("Digite um valor: ");
    scanf("%d", &n);

    for(int rep = n-1; rep > 0; rep--){
        if(n%rep == 0){
            printf("O número %d é o maior divisor de %d\n", rep, n);
            break;
        }
    }
    return 0;
}
