package view;

public class Tela {

	public static void main(String[] args) {
		Interface i = new Interface();

		i.dados("Ler");
		i.menu();
		i.dados("Escrever");
	}

}
