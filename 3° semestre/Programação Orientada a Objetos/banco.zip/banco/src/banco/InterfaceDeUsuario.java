package banco;

import java.util.Scanner;

public class InterfaceDeUsuario {

	private ContaCorrente[] asContas = new ContaCorrente[1000];
	private int quantasContas = 0;
	private Cliente[] osClientes = new Cliente[1000];
	private int quantosClientes= 0;
	
	public void mostrarMenuPrincipal() {
		
		Scanner entrada = new Scanner(System.in);
		
		//declara��o de vari�veis auxiliares
		int numero, opcao;
		ContaCorrente tempConta;
		Cliente tempCliente;
		double valor;
		String nome,endereco,cpf;
		
		System.out.println("0.Sair");
		System.out.println("1.Cadastrar Cliente");
		System.out.println("2.Cadastrar ContaCorrente");
		System.out.println("3.Depositar em uma conta");
		System.out.println("4.Fazer uma retirada de uma conta");
		System.out.println("5.Mostrar o saldo de uma conta");
		System.out.println("6.Mostrar os nomes e cpfs de todos os clientes cadastrados");
		System.out.println("7.Mostrar os n�meros e saldos de todas as contas cadastradas");
		opcao = entrada.nextInt();
		
		while(opcao != 0) {
			switch(opcao) {
			case 1 :
				System.out.println("Forne�a o nome do novo cliente");
				entrada.nextLine();
				nome = entrada.nextLine();
				System.out.println("Forne�a o cpf do novo cliente");
				cpf = entrada.nextLine();
				tempCliente = new Cliente(nome,cpf);
				osClientes[quantosClientes] = tempCliente;
				quantosClientes++;
				break;
			case 2 :
				System.out.println("Forne�a o cpf do titular");
				cpf = entrada.nextLine();
				tempCliente = null ;
				for(int i=0 ; i<quantosClientes ; i++) {
					if(cpf.equals(osClientes[i].getCpf())){
						tempCliente = osClientes[i];
						break;
					}
				}
				if(tempCliente != null) {
					System.out.println("forne�a o n�mero da conta");
					numero = entrada.nextInt();
					tempConta = new ContaCorrente();
					tempConta.setNumero(numero);
					tempConta.setTitular(tempCliente);
					asContas[quantasContas] = tempConta ;
					quantasContas++;					
				}
				else {
					System.out.println("cliente n�o encontrado");
				}
				
				break;
			case 3 :
				System.out.println("forne�a o n�mero da conta");
				numero = entrada.nextInt();
				System.out.println("forne�a o valor");
				valor = entrada.nextDouble();
				for(int i=0 ; i<quantasContas ; i++) {
					if(numero == asContas[i].getNumero()) {
						asContas[i].depositar(valor);
					}
				}
				break;
			case 4 :
				break;
				
			}
			System.out.println("0.Sair");
			System.out.println("1.Cadastrar Cliente");
			System.out.println("2.Cadastrar ContaCorrente");
			System.out.println("3.Depositar em uma conta");
			System.out.println("4.Fazer uma retirada de uma conta");
			System.out.println("5.Mostrar o saldo de uma conta");
			System.out.println("6.Mostrar os nomes e cpfs de todos os clientes cadastrados");
			System.out.println("7.Mostrar os n�meros e saldos de todas as contas cadastradas");
			opcao = entrada.nextInt();
		}
		entrada.close();
	}
	
}
