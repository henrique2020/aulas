package banco;

public class Cliente {

	//vari�veis de inst�ncia
	private String nome;
	private String endereco;
	private String cpf;
	private int idade;
	
	public Cliente(String nome) {
		this.nome = nome;
	}
		
	public Cliente(String nome, String cpf) {
		this.nome = nome;
		this.cpf = cpf;
	}



	//m�todo de inst�ncia
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	
	
}
