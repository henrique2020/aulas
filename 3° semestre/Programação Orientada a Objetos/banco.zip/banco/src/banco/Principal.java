package banco;

public class Principal {

	public static void main(String[] args) {

		InterfaceDeUsuario i = new InterfaceDeUsuario();
		i.mostrarMenuPrincipal();

	}

}
