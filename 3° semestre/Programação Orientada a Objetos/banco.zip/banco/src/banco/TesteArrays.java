package banco;

public class TesteArrays {

	public static void main(String[] args) {
		
		
		String[] nomes = new String[10];
		nomes[0] = "marcos";
		
		
		Cliente[] osClientes;
		osClientes = new Cliente[5];
		
		osClientes[0] = new Cliente();
		osClientes[1]= new Cliente();
		osClientes[0].defineNome("marcos");
		osClientes[1].defineNome("maria");
		
		
				
		
		int[] vet = new int[5];
		vet[0] = 10000;
		vet[1] = 234;
		vet[2] = 345;
		vet[3] = 456;
		vet[4] = 567;
		//for each
		
		for(int cada : vet ) {
			System.out.println("valor "+cada);
		}
		/*
		for(int i=0 ;   i<vet.length    ; i++) {
			System.out.println("valor "+vet[i]);
			
		}
		*/
	}
	
}






