package view;

import java.util.Scanner;

import loja.Impressora;
import loja.Notebook;
import loja.Produto;

public class InterfaceDeUsuario {

		public Produto[] produtos = new Produto[100];  
		public int tamanho = 0 ;
		
		Scanner entrada = new Scanner(System.in);
		
		public void menuPrincipal()
		{
			String marca;
			double precoDeCusto, tamanhoDeTela;
			Produto temp;
			int ppm, memoria;
			
			System.out.println("0.Sair");
			System.out.println("1.Cadastrar Impressora");
			System.out.println("2.Cadastrar Notebook");
			System.out.println("3.Mostrar todos");
			System.out.println("4.Mostrar por pre�o");
			int opcao = entrada.nextInt();
			while(opcao != 0)
			{		
				switch(opcao)
				{
				case 1:
					System.out.print("Marca: ");
					entrada.nextLine();
					marca = entrada.nextLine();
					System.out.print("Pre�o de custo: ");
					precoDeCusto = entrada.nextDouble();
					System.out.print("PPM: ");
					ppm = entrada.nextInt();
					temp = new Impressora(marca,precoDeCusto,ppm);
					produtos[tamanho] = temp;
					tamanho++;
					break;
				case 2:
					System.out.print("Marca: ");
					entrada.nextLine();
					marca = entrada.nextLine();
					System.out.print("Pre�o de custo: ");
					precoDeCusto = entrada.nextDouble();
					System.out.print("Tamanho de tela: ");
					tamanhoDeTela = entrada.nextDouble();
					System.out.print("Mem�ria: ");
					memoria = entrada.nextInt();
					temp = new Notebook(marca,precoDeCusto,tamanhoDeTela,memoria);
					produtos[tamanho] = temp;
					tamanho++;
					break;
				case 3:
					for(int i=0; i<tamanho; i++)
					{
						System.out.println(produtos[i]);
					}
					break;
				case 4:

					break;
				
				}
				System.out.println("0.Sair");
				System.out.println("1.Cadastrar Diretor");
				System.out.println("2.Cadastrar Gerente");
				System.out.println("3.Cadastrar Cliente");
				System.out.println("4.Mostrar os clientes cadastrados");
				opcao = entrada.nextInt();
			}
		}
	}
