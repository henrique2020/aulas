package loja;

public class Notebook extends Produto {

	protected double tamanhoDeTela;
	protected int memoria;
	
	public Notebook(String marca, double precoDeCusto, double tamanhoDeTela, int memoria) {
		super(marca, precoDeCusto);
		this.memoria = memoria;
		this.tamanhoDeTela = tamanhoDeTela;
	}

	@Override
	public double precoFinal() {
		return this.precoDeCusto * 1.2;
	}

	@Override
	public String toString() {
		return "Notebook - Memoria: "+memoria+" Tamnho de Tela: "+tamanhoDeTela;
	}
	
	
}
