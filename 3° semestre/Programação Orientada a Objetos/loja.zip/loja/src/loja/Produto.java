package loja;

public abstract class Produto {

	protected String marca;
	protected double precoDeCusto;
	
	public Produto(String marca, double precoDeCusto) {
		super();
		this.marca = marca;
		this.precoDeCusto = precoDeCusto;
	}

	public abstract double precoFinal();
	
	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public double getPrecoDeCusto() {
		return precoDeCusto;
	}

	public void setPrecoDeCusto(double precoDeCusto) {
		this.precoDeCusto = precoDeCusto;
	}
	
	
}
