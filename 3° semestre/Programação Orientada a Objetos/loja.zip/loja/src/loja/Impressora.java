package loja;

public class Impressora extends Produto {

	protected int ppm ;
	
	public Impressora(String marca, double precoDeCusto, int ppm) {
		super(marca, precoDeCusto);
		this.ppm = ppm;
	}

	@Override
	public double precoFinal() {
		if(ppm<20) {
			return this.precoDeCusto * 1.2;
		}
		else {
			return this.precoDeCusto * 1.3;
		}
	}

	@Override
	public String toString() {
		return "Impressora - PPM: "+ppm;
	}
}
