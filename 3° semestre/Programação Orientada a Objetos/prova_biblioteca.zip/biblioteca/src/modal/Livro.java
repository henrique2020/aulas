package modal;

public class Livro {
	private String titulo;
	private int ano_publicacao;
	private String autor;
	
	public Livro(String titulo, int ano_publicacao) {
		this.titulo = titulo;
		this.ano_publicacao = ano_publicacao;
	}
	
	public Livro(String titulo, int ano_publicacao, String autor) {
		this.titulo = titulo;
		this.ano_publicacao = ano_publicacao;
		this.autor = autor;
	}
	
	
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public int getAno_publicacao() {
		return ano_publicacao;
	}
	public void setAno_publicacao(int ano_publicacao) {
		this.ano_publicacao = ano_publicacao;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	
}
