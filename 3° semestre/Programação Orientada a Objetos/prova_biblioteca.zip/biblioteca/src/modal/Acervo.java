package modal;

import java.util.ArrayList;

public class Acervo {
	
	private ArrayList<Livro> acervo;
	private int tamanho_maximo_acervo = 10;
	
	public Acervo() {
		this.acervo = new ArrayList <Livro>();
	}
	
	public int incluirLivro(Livro livro) {
		if(acervo.size() == tamanho_maximo_acervo) {
			return 1;
		}
		
		for(Livro tempLivro : acervo) {
			if(livro.getTitulo().toLowerCase()
				.equals(tempLivro.getTitulo().toLowerCase())) {
				return 2;
			}
		}
		
		acervo.add(livro);
		return 0;
	}
	
	public ArrayList<Livro> pesquisa(int ano) {
		ArrayList <Livro> livros = new ArrayList <Livro>();
		for(Livro tempLivro : acervo) {
			if(tempLivro.getAno_publicacao() > ano) {
				livros.add(tempLivro);
			}
		}
		return livros;
	}
	
}
