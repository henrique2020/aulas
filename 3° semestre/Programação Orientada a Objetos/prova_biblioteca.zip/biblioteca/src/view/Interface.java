package view;

import java.util.ArrayList;
import java.util.Scanner;

import modal.Acervo;
import modal.Livro;

public class Interface {

	private Scanner scan = new Scanner(System.in);
	private Acervo acervo = new Acervo();
	private Livro livro;
	
	private int op() {
		int op;
		
		System.out.println();
		System.out.println("O que deseja fazer?");
		System.out.println("1. Incluir novo livro");
		System.out.println("2. Pesquisar livros publicados a partir de XXXX ano");
		System.out.println("0. Sair");
		
		System.out.print("Op��o desejada: ");
		op = scan.nextInt();
		scan.nextLine();	//Limpando o Buffer
		
		System.out.println();
		return op;
	}
	
	private boolean insere_autor() {
		System.out.print("Gostaria de citar o AUTOR do livro (S/N)?" );
		String resposta = scan.nextLine().toUpperCase();
		if(
			resposta.equals("S") || resposta.equals("SIM") ||
			resposta.equals("Y") || resposta.equals("YES")
		) { return true; }
		
		else if(
			resposta.equals("N") || resposta.equals("NAO") ||
			resposta.equals("N�O") || resposta.equals("NO")
		) { return false; }
		
		else { 
			System.out.println("Resposta inv�lida!");
			return insere_autor();
		}
		
	}
	
	public void Tela() {
		boolean rep = true;
		String titulo_livro, autor_livro;
		int op, ano_livro, insercao;
		ArrayList <Livro> livros_pesquisa;
		
		System.out.println("Seja bem vindo a Biblioteca!");
		
		while(rep) {
			op = op();
			
			switch(op){
			case 0:
				System.out.println("Voc� escolheu sair");
				rep = false;
				break;
			case 1:
				System.out.println("Preencha as perguntas abaixo para incluir um novo livro no Acervo");
				
				System.out.print("Informe o T�TULO do livro: ");
				titulo_livro = scan.nextLine();
				
				System.out.print("Informe o ANO DE PUBLICA��O do livro: ");
				ano_livro = scan.nextInt();
				scan.nextLine();	//Limpando o Buffer
				
				if(insere_autor()) { 
					System.out.print("Informe o AUTOR do livro: ");
					autor_livro = scan.nextLine();
					livro = new Livro(titulo_livro, ano_livro, autor_livro);
				}
				else {
					livro = new Livro(titulo_livro, ano_livro);
				}
				
				insercao = acervo.incluirLivro(livro);
				if(insercao == 0) {
					
				} else if(insercao == 1) {
					System.out.println("O acervo j� est� em sua capacidade m�xima, n�o � poss�vel incluir novos livros");
					
				} else if(insercao == 2) {
					System.out.printf("O livro \"%s\" j� se econtra no acervo\n", titulo_livro);
				}
				
				break;
			case 2:
				System.out.print("Informe a data posterior (ANO) a qual deseja listar os livros: ");
				ano_livro = scan.nextInt();
				scan.nextLine();	//Limpando o Buffer
				
				livros_pesquisa = acervo.pesquisa(ano_livro);
				if(livros_pesquisa.size() > 0) {
					System.out.printf("A seguir se encontra a lista de livros publicados ap�s %d\n", ano_livro);
					for(Livro tempLivro : livros_pesquisa) {
						System.out.printf(" - %s (%d)\n", tempLivro.getTitulo(), tempLivro.getAno_publicacao());
					}
				}
				
				
				break;
			}
		}
	}
}
