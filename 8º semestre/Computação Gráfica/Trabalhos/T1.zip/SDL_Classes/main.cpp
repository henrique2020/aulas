#define SDL_MAIN_HANDLED
#include <SDL2/SDL.h>
#include <stdio.h>
#include <math.h>
#include <vector>

#include <Color.h>
#include <Point.h>
#include <Line.h>
#include <Circle.h>

// SDL stuff
SDL_Window* pWindow = 0;
SDL_Renderer* pRenderer = 0;
SDL_Surface * window_surface;

Color red = Color(window_surface, 255, 0, 0);
Color black = Color(window_surface, 0, 0, 0);
Color white = Color(window_surface, 255, 255, 255);
Color brown =  Color (window_surface, 89, 65, 38);

int yRoda = 680;
int raio_interno = 30;
int raio_externo = 40;
int graus = -30;
int grau_rotacao_roda = 5;
int rotacao_roda = 0;
int velocidade = 10;
double x = 0;
double y = 0;


Line* lines = (Line*)malloc(99*sizeof(Line));
Circle* circles = (Circle*)malloc(99*sizeof(Circle));

void display()
{
    //Chão
    lines[0] = Line(window_surface, pRenderer, Point(0,720), Point(1500,720), brown);

    //Carcaça do carro
    //Trás
    lines[1] = Line(window_surface, pRenderer, Point(15, 675), Point(0, 675), red);
    lines[2] = Line(window_surface, pRenderer, Point(0, 675), Point(0, 585), red);
    lines[3] = Line(window_surface, pRenderer, Point(0, 585), Point(20, 540), red);
    //Cima
    lines[4] = Line(window_surface, pRenderer, Point(20, 540), Point(10, 540), red);
    lines[5] = Line(window_surface, pRenderer, Point(10, 540), Point(30, 530), red);
    lines[6] = Line(window_surface, pRenderer, Point(30, 530), Point(305, 530), red);
    //Frente
    lines[7] = Line(window_surface, pRenderer, Point(305, 530), Point(350, 570), red);
    lines[8] = Line(window_surface, pRenderer, Point(350, 570), Point(450, 585), red);
    lines[9] = Line(window_surface, pRenderer, Point(450, 585), Point(475, 620), red);
    lines[10] = Line(window_surface, pRenderer, Point(475, 620), Point(475, 635), red);
    //Baixo
    lines[11] = Line(window_surface, pRenderer, Point(475, 635), Point(470, 675), red);
    lines[12] = Line(window_surface, pRenderer, Point(470, 675), Point(445, 675), red);
    lines[13] = Line(window_surface, pRenderer, Point(445, 675), Point(425, 635), red);
    lines[14] = Line(window_surface, pRenderer, Point(425, 635), Point(355, 635), red);
    lines[15] = Line(window_surface, pRenderer, Point(355, 635), Point(335, 675), red);
    lines[16] = Line(window_surface, pRenderer, Point(335, 675), Point(125, 675), red);
    lines[17] = Line(window_surface, pRenderer, Point(125, 675), Point(105, 635), red);
    lines[18] = Line(window_surface, pRenderer, Point(105, 635), Point(35, 635), red);
    lines[19] = Line(window_surface, pRenderer, Point(35, 635), Point(15, 675), red);
    //Vidros
    //Retângulo Traseiro
    lines[20] = Line(window_surface, pRenderer, Point(70, 580), Point(100, 590), red);
    lines[21] = Line(window_surface, pRenderer, Point(70, 540), Point(70, 580), red);
    lines[22] = Line(window_surface, pRenderer, Point(70, 540), Point(100, 540), red);
    //Trás
    lines[23] = Line(window_surface, pRenderer, Point(100, 540), Point(190, 540), red);
    lines[24] = Line(window_surface, pRenderer, Point(190, 540), Point(190, 590), red);
    lines[25] = Line(window_surface, pRenderer, Point(190, 590), Point(100, 590), red);
    lines[26] = Line(window_surface, pRenderer, Point(100, 590), Point(100, 540), red);
    //Frente
    lines[27] = Line(window_surface, pRenderer, Point(205, 540), Point(295, 540), red);
    lines[28] = Line(window_surface, pRenderer, Point(295, 540), Point(295, 590), red);
    lines[29] = Line(window_surface, pRenderer, Point(295, 590), Point(205, 590), red);
    lines[30] = Line(window_surface, pRenderer, Point(205, 590), Point(205, 540), red);
    //Tiângulo frontal
    lines[31] = Line(window_surface, pRenderer, Point(295, 540), Point(330, 580), red);
    lines[32] = Line(window_surface, pRenderer, Point(330, 580), Point(295, 590), red);

    //Aros
    lines[33] = Line(window_surface, pRenderer, Point(70-raio_interno,yRoda), Point(70+raio_interno,yRoda), black);
    lines[34] = Line(window_surface, pRenderer, Point(70,yRoda-raio_interno), Point(70,yRoda+raio_interno), black);
    lines[35] = Line(window_surface, pRenderer, Point(390-raio_interno,yRoda), Point(390+raio_interno,yRoda), black);
    lines[36] = Line(window_surface, pRenderer, Point(390,yRoda-raio_interno), Point(390,yRoda+raio_interno), black);

    //Rodas
    circles[0] = Circle(window_surface, pRenderer, Point(70, yRoda), raio_interno, black);
    circles[1] = Circle(window_surface, pRenderer, Point(70, yRoda), raio_externo, black);
    circles[2] = Circle(window_surface, pRenderer, Point(390, yRoda), raio_interno, black);
    circles[3] = Circle(window_surface, pRenderer, Point(390, yRoda), raio_externo, black);

    //Chao
    lines[0].rotation(graus);
    lines[0].draw();

    double m = lines[0].getCoeficiente();

    x+=velocidade;
    y=x*m;

    //Veiculo
    for (int i = 1; i < 33; i++) {
        if(velocidade < 0){
            lines[i].inversor();
            lines[i].transalation(460, 0);
        }
        lines[i].rotation(graus);
        lines[i].transalation(x, y);
        lines[i].draw();
    }

    //Rodas
    for (int i = 0; i < 4; i++) {
        circles[i].rotation(graus);
        circles[i].transalation(x, y);
        circles[i].draw();
    }

    //Aros
    for (int i = 33; i < 37; i++){
        //Girar o Aro
        Point center_roda;
        if(37-i > 2)
            center_roda = Point(70, yRoda);
        else
            center_roda = Point(390, yRoda);


        lines[i].rotation(rotacao_roda, center_roda);

        //Ajustar a posição com base na localização da roda
        lines[i].rotation(graus);
        lines[i].transalation(x, y);
        lines[i].draw();
    }


    if ((lines[3].getStart().getX() > window_surface->w && lines[12].getStart().getX() > window_surface->w+460)
        || (lines[12].getStart().getX() < 0-460 && lines[3].getStart().getX() < 0)){
        velocidade *= -1;
        grau_rotacao_roda *= -1;
        SDL_Delay(500);
    }

    rotacao_roda += grau_rotacao_roda;
}

// Driver code
int main(int argc, char* args[])
{
	SDL_Event event;

	// initialize SDL
	if (SDL_Init(SDL_INIT_EVERYTHING) >= 0)
	{
		// if succeeded create our window
		pWindow = SDL_CreateWindow("SDL_Classes",
					SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
														1080, 720,
												SDL_WINDOW_SHOWN);

		// if the window creation succeeded create our renderer
		if (pWindow != 0) {
			pRenderer = SDL_CreateRenderer(pWindow, -1, 0);
			window_surface = SDL_GetWindowSurface(pWindow);
        }

	}
	else
		return 1; // sdl could not initialize

	while (1)
	{
		if (SDL_PollEvent(&event) && event.type == SDL_QUIT)
			break;

		// Sets background color to white
		//SDL_SetRenderDrawColor(pRenderer, 173, 216, 230, 255);
		SDL_SetRenderDrawColor(pRenderer, 255, 255, 255, 255);
		SDL_RenderClear(pRenderer);

        display();

		// show the window
		SDL_RenderPresent(pRenderer);

		SDL_Delay(1000 / 24);
	}

	// clean up SDL
	SDL_Quit();
	return 0;
}
