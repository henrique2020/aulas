#ifndef MOVEMENT_H
#define MOVEMENT_H

#include <Point.h>
#include <math.h>
#include<SDL2/SDL.h>

class Movement
{
    public:
        Movement();
        virtual ~Movement();

        static void origin(Point &point, Point difference, int action);
        static void rotation(Point &point, double graus);
        static void transalation(Point &point, double x, double y);
        static double grausToRadius(double graus);

    protected:

    private:

};

#endif // MOVEMENT_H
