#ifndef COMPONENT_H
#define COMPONENT_H

#include <SDL2/SDL.h>
#include <Point.h>

class Component {
public:
    SDL_Surface* window_surface;
    SDL_Renderer* pRenderer;

    Component();
    Component(SDL_Surface* window_surface, SDL_Renderer* pRenderer);

    virtual ~Component();
    virtual void draw() = 0;
};

#endif // COMPONENT_H
