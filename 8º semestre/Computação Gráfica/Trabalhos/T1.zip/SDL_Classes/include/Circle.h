#ifndef CIRCLE_H
#define CIRCLE_H

#include <Movement.h>
#include <Point.h>
#include <Color.h>
#include <SDL2/SDL.h>

class Circle
{
    public:
        Circle();
        Circle(SDL_Surface * window_surface, SDL_Renderer * pRenderer, Point start, int radius, Color color);
        void draw();
        virtual ~Circle();

        void transalation(double x, double y);
        void rotation(double graus);

    protected:

    private:
        Point start;
        Point end;
        int radius;
        Color color;
        SDL_Renderer * pRenderer;
        SDL_Surface * window_surface;
        void setPixel(int x, int y, int r, int g, int b);
        void setPixel(int x, int y, Color color);
        void setPixel(int x, int y, Uint32 cor);
        Uint32 getPixel(int x, int y);
        void bresenham(int xc, int yc, int x, int y, Color color);
};

#endif // CIRCLE_H
