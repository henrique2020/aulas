#include "Circle.h"

Circle::Circle()
{
    //ctor
}

Circle::~Circle()
{
    //dtor
}

Circle::Circle(SDL_Surface * window_surface, SDL_Renderer * pRenderer, Point start, int radius, Color color) {
    this->start = start;
    this->radius = radius;
    this->color = color;
    this->window_surface = window_surface;
    this->pRenderer = pRenderer;
}

void Circle::setPixel(int x, int y, Uint32 cor) {

    Color c = Color(this->window_surface);
    Uint8 r = c.getColorComponent(cor, 'r');
    Uint8 g = c.getColorComponent(cor, 'g');
    Uint8 b = c.getColorComponent(cor, 'b');
    this->setPixel(x, y, r, g, b);
}

void Circle::setPixel(int x, int y, Color color) {
	this->setPixel(x, y, color.getR(),color.getG(),color.getB());
}

void Circle::setPixel(int x, int y, int r, int g, int b) {
	SDL_SetRenderDrawColor(pRenderer, r, g, b, 255);
	SDL_RenderDrawPoint(pRenderer, x, y);
}

void Circle::draw() {
    int x = 0, y = this->radius;
    int decesionParameter = 3 - 2 * radius;
    this->bresenham(this->start.getX(), this->start.getY(), x, y, this->color);

    while(y >= x){
        x++;
        if(decesionParameter > 0){
            y--;
            decesionParameter = decesionParameter + 4 * (x - y) + 10;

        } else {
            decesionParameter = decesionParameter + 4 * x + 6;
        }

        this->bresenham(this->start.getX(), this->start.getY(), x, y, this->color);
    }

}

Uint32 Circle::getPixel(int x, int y)
{
    int bpp = window_surface->format->BytesPerPixel;
    /* Here p is the address to the pixel we want to retrieve */
    Uint8 *p = (Uint8 *) window_surface->pixels + y * window_surface->pitch + x * bpp;

    switch (bpp)
    {
        case 1:
            return *p;
            break;

        case 2:
            return *(Uint16 *)p;
            break;

        case 3:
            if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
                return p[0] << 16 | p[1] << 8 | p[2];
            else
                return p[0] | p[1] << 8 | p[2] << 16;
            break;

            case 4:
                return *(Uint32 *)p;
                break;

            default:
                return 0;       /* shouldn't happen, but avoids warnings */
      }
}

void Circle::bresenham(int xc, int yc, int x, int y, Color color){
    setPixel(xc+x, yc+y, color);
    setPixel(xc-x, yc+y, color);
    setPixel(xc+x, yc-y, color);
    setPixel(xc-x, yc-y, color);
    setPixel(xc+y, yc+x, color);
    setPixel(xc-y, yc+x, color);
    setPixel(xc+y, yc-x, color);
    setPixel(xc-y, yc-x, color);
}

void Circle::rotation(double graus){
    Point oringin = Point(0, this->window_surface->h);

    Movement::origin(this->start, oringin, 0);
    Movement::rotation(this->start, graus);
    Movement::origin(this->start, oringin, 1);
}

void Circle::transalation(double x, double y){
    Movement::transalation(this->start, x, y);
    Movement::transalation(this->end, x, y);
}
