#include "Movement.h"

Movement::Movement()
{
    //ctor
}

Movement::~Movement()
{
    //dtor
}

double Movement::grausToRadius(double graus){
    return graus * 0.017453293;
}

void Movement::origin(Point &point, Point difference, int action) {
    if (action == 0) {
        point.setX(point.getX() - difference.getX());
        point.setY(point.getY() - difference.getY());
    } else {
        point.setX(point.getX() + difference.getX());
        point.setY(point.getY() + difference.getY());
    }
}

void Movement::transalation(Point &point, double x, double y){
    point.setX(point.getX()+x);
    point.setY(point.getY()+y);
}

void Movement::rotation(Point &point, double graus) {
    double radius = grausToRadius(graus);
    double originalX = point.getX();

    point.setX(
        point.getX()*cos(radius) - point.getY()*sin(radius)
    );
    point.setY(
        originalX*sin(radius) + point.getY()*cos(radius)
    );
}

