#include "Component.h"

Component::Component()
{
    //ctor
}

Component::~Component()
{
    //dtor
}


Component::Component(SDL_Surface* window_surface, SDL_Renderer* pRenderer){
    this->window_surface = window_surface;
    this->pRenderer = pRenderer;
}
